
def make_label(value, type, pcnt = None):
    l = format(value, ',')
    if type == 'Cost':
        l = '$' + l
    if type == 'Area':
        l = l + 'ha'
    if pcnt:
        l = l + '(' + pcnt + '%)'
    return l