from dataclasses import dataclass
from .arrow import Arrow


# input data generator for hydronet delta arrow dashboard bar

@dataclass
class DeltaArrows:
    """
    Create data for a bar with delta arrows for a set of metrics
    metric_values -- a dict with metric values to visualize. The keys in the dict are used as labels
     """
    metric_values: dict
    icons = dict(Area='area.png', Cost='dollar.png', Trees='tree.png', Sites='sites.png')

    def make_data(self):
        return map(lambda m: {dict(label=m, icon=self.icons[m], value=Arrow(self.metric_values[m]), )},
                    self.metric_values.keys())
