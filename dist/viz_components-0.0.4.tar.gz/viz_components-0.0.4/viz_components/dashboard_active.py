from dataclasses import dataclass, field
from .dashboard_helpers import make_label
from json import dumps

# input data generator for the 'active' dashboard

@dataclass
class DashboardActive:
    """
    Create data for the Hydronet dashboard during the 'active' phase

     dashboard_data -- a dict with one entry for each metric; these entries should be dicts with the following entries:
             delta: change in metric value from last approved plan
             target: plan target for this metric
             breakdown_by_stage: breakdown by execution stage:
                                 a dict with elements 'planned', 'active', 'ready for inspection', 'completed'
             breakdown_by_MRS: breakdown by MRS/non-MRS: a dict with elements 'MRS', 'non-MRS'
             breakdown_by_ET: breakdown by ET/ROW: a dict with elements 'ET', 'ROW'
     """
    dashboard_data: dict
    icons = dict(Area='area.png', Cost='dollar.png', Trees='tree.png', Sites='sites.png')

    @property
    def data(self):
        return self.make_data()

    label_postfix = dict(Area='ha', Cost='dollar.png', Trees='tree.png', Sites='sites.png')

    def make_delta_data(self):
        deltas = dict()
        for m in self.dashboard_data.keys():
            deltas[m] = self.dashboard_data[m].delta
        return deltas


    def make_doughnut_data(self):
        doughnuts = dict()
        for m in self.dashboard_data.keys():
            labels = self.dashboard_data[m]['breakdown_by_stage'].keys()
            values = self.dashboard_data[m]['breakdown_by_stage'].values()
            center_label = make_label(value=sum(values), type=m)
            doughnuts[m] = {'data_labels': labels, 'data_values': values, center_text:[center_label]}
        return doughnuts


    def make_bar_data(self):
        bar_data = {'y_labels': [],
                    'y_label_images': {},
                    'data': [{'label': 'Planned', 'backgroundColor': 'grey', 'data': [],},
                             {'label': 'Completed', 'backgroundColor': 'green', 'data': [],}],
                    'bar_labels': {'Planned': {'labels':[], 'color':'white',},
                                   'Completed': {'labels':[], 'color':'white',}}}
        for m in self.dashboard_data.keys():
            bar_data['y_labels'].append(m)
            bar_data['y_label_images'].append(self.icons[m])
            total = sum(self.dashboard_data[m]['breakdown_by_stage'].values)
            completed = self.dashboard_data[m]['breakdown_by_stage']['completed']
            planned = total - self.dashboard_data[m]['breakdown_by_stage']['completed']
            target = self.dashboard_data[m]['target']
            bar_data['data'][0]['data'].append(planned/target)
            bar_data['data'][1]['data'].append(completed/target)
            bar_data['bar_labels']['Planned']['labels'].append(make_label(value=planned, type=m))
            bar_data['bar_labels']['Completed']['labels'].append(make_label(value=completed, type=m, pcnt=round(100*completed/planned)))
        return bar_data


