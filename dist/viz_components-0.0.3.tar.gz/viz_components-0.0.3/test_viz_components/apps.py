from django.apps import AppConfig


class TestVizComponentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'test_viz_components'
