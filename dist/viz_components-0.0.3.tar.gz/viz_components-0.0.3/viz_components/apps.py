from django.apps import AppConfig


class VizComponentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'viz_components'
